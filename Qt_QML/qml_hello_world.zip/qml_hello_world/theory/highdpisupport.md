### High DPI Support in Qt

For drawing pixmaps and artworks in high resolution.


