Ashley Tharp

Source Files:

Problem.h, Problem.cpp
Node.h, Node.cpp
init.cpp
main.cpp

Developed on Windows using Microsoft Visual Studio 2013

HOW TO RUN:

to run from the command line, navigate to the project folder and run
search [-cost] <BFS|DFS|UCS|GS|A-star> <inputfile>