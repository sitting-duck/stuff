#include "MathTree.h"

MathTree::Node::Node (const Token & T): Token (T)
	{
	}

MathTree::Node::~Node ()
	{
	}

MathTree::MathTree ()
	{
	}

MathTree::~MathTree ()
	{
	}

void MathTree::InsertBinaryOperator (const Token & T)
	{
	WCS_Pointer <Node>	pNode (new Node (T));

	while ((pLastOperator.Exists ()) && ((*pLastOperator).GetPrecedence () >= (*pNode).GetPrecedence ()))
		pLastOperator = (*pLastOperator).pParent;

	if (pLastOperator.DoesNotExist ())
			{
			(*pRoot).pParent	= pNode;
			(*pNode).pLeft		= pRoot;
			pRoot				= pNode;
			}
		else
			{
			(*pNode).pLeft				= (*pLastOperator).pRight;
			(*(*pNode).pLeft).pParent	= pNode;
			(*pLastOperator).pRight		= pNode;
			(*pNode).pParent			= pLastOperator;
			}
	pLastOperator = pNode;
	}

void MathTree::InsertOperand (const Token & T)
	{
	WCS_Pointer <Node>	pNode (new Node (T));

	if (pRoot.DoesNotExist ())
			pRoot = pNode;
		else
			{
			(*pLastOperator).pRight = pNode;
			(*pNode).pParent		= pLastOperator;
			}
	}

void MathTree::InsertUnaryOperator (const Token & T)
	{
	Token Temp (Token::ConstantToken, 0);

	InsertOperand (Temp);
	InsertBinaryOperator (T);
	}

WCS_Pointer <MathTree::Node> & MathTree::GetLeftMostOperator (WCS_Pointer <Node> & pNode)
	{
	if (pNode.Exists ())
			{
			while ((*pNode).pLeft.Exists ())
				{
				(*pNode).IsLeftSideDone	= false;
				pNode					= (*pNode).pLeft;
				}
			pNode = (*pNode).pParent;
			}
		else;
	return pNode;
	}

Variable::ValueType MathTree::Evaluate ()
	{
	if (pRoot.Exists ())
			{
			WCS_Pointer <Node> pNode;

			pNode = GetLeftMostOperator (pRoot);
			while (pNode.Exists ())
				if (!(*pNode).IsLeftSideDone)
						{
						(*pNode).SetValue ((*(*pNode).pLeft).GetValue ());
						(*pNode).IsLeftSideDone	= true;
						pNode					= GetLeftMostOperator ((*pNode).pRight);
						}
					else
						{
						switch ((*pNode).GetType ())
							{
							case Token::OperatorPlusToken:
										(*pNode).SetValue ((*pNode).GetValue () + (*(*pNode).pRight).GetValue ());
										break;
							case Token::OperatorMinusToken:
							case Token::OperatorSlashToken:
										if ((*(*pNode).pRight).GetValue () == 0)
												throw DivideByZero;
							case Token::OperatorAsteriskToken:
							}
						pNode = (*pNode).pParent;
						}
			return (*pRoot).GetValue ();
			}
		else
			return 0;
	}

